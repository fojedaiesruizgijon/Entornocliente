$(document).ready(function () {
   //alert("Hola");
    // $('.btn-popover').popover('show');
    // if($(".bnt-popover").length){
    //     alert("The element you're testing is present.");
    // }
    $('[data-toggle="popover"]').popover();
    
    $('.toast').toast();

}
);
